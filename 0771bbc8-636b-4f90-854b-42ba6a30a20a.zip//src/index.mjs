// Contact form submission handler
document
  .getElementById("subscriptionForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();
    const email = document.getElementById("email").value;

    // Simple validation
    if (email) {
      alert(`Thank you for subscribing with email: ${email}`);
      document.getElementById("email").value = ""; // Clear the input field
    } else {
      alert("Please enter a valid email.");
    }
  });
