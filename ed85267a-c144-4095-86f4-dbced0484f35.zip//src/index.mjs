// Carousel functionality
let currentIndex = 0;
const slides = document.querySelectorAll(".carousel-slide");
const totalSlides = slides.length;

// Next and Previous buttons for the carousel
document.getElementById("next").addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % totalSlides; // Go to next slide
  updateCarousel();
});

document.getElementById("prev").addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + totalSlides) % totalSlides; // Go to previous slide
  updateCarousel();
});

// Update carousel position based on currentIndex
function updateCarousel() {
  const offset = -currentIndex * 100;
  document.querySelector(
    ".carousel-images"
  ).style.transform = `translateX(${offset}%)`;
}
// Modal functionality
const modal = document.getElementById("aboutModal");
const showModalBtn = document.getElementById("showModalBtn");
const closeModalBtn = document.getElementById("closeModalBtn");

// Show modal when the button is clicked
showModalBtn.addEventListener("click", () => {
  modal.style.display = "flex";
});

// Close modal when the close button is clicked
closeModalBtn.addEventListener("click", () => {
  modal.style.display = "none";
});

// Close modal when clicked outside the modal content
window.addEventListener("click", (e) => {
  if (e.target === modal) {
    modal.style.display = "none";
  }
});
